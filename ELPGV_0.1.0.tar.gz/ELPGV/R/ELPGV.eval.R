# Just the welcome function that will appear every time that your run the program
ELPGV.welcome <-function()
{
  message(paste("#", paste(rep("-", 24), collapse=""), "Welcome to ELPGV", paste(rep("-", 23), collapse=""), "#", sep=""), "\n")
  cat("#          _\\\\|//_                                              #\n")
  cat("#         (^ o-o ^)                                             #\n")
  cat("#========ooO-(_)-Ooo============================================#\n")
  cat("#                         ELPGV:Prediction of genetic values    #\n")
  cat("#                            based on ensemble learning         #\n")
  cat("#                             gulinlin_141006@163.com           #\n")
  cat("#       .oooO    Oooo.          fangming618@126.com             #\n")
  cat("#       (   )    (   )             June, 2020                   #\n")
  cat("#========\\ (======) /============Version: 0.1.0=================#\n")
  cat("#         \\_)    (_/                                            #\n")
  message("#---------------------------------------------------------------#\n")
}
#' @title ELPGV evaluating indicator function
#'
#' @param real is observed phenotype
#' @param pred is the predicted values
#' # Note that real and pred must in the same order
#'
#' @return evaluating indicator:auc(Disease data) or cor
#' @export
#' @examples
ELPGV.eval <- function(real, pred, type=c("cor", "auc"))
{
  switch(
    match.arg(type),
    "cor"={eval <- cor(real, pred)},
    "auc"={
      if(sum(c(0,1) %in% unique(real)) != 2) stop("Only two levels(case/1,control/0) are allowed!")
      X <- cbind(real,pred)
      X <- X[order(X[,2]),]
      N.case <- sum(as.numeric(X[,1]) == 1)
      N.cont <- sum(as.numeric(X[,1]) == 0)
      case.index <- which(as.numeric(X[,1]) == 1)
      case.index.mean <- mean(case.index)
      eval <- (1/N.cont)*(case.index.mean-0.5*N.case-0.5)
    }
  )
  return(eval)
}
