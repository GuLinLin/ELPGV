#' @title DEPSO fitness function
#'
#' @param weight The weight of the basic models for ensemble.
#' @param para_deliver A list contains the $predict_models, $indepedent_pheno and $train_num.
#'
#' @return $whole_corre The correlation coefficient between predicted value and real value.
#' @export
#'
DEPSO_fitness<-function(weight, para_deliver, type ="cor")
{
  weight_predict <- apply(t(t(para_deliver$predict_models[para_deliver$train_num,])*weight),1,sum)/sum(weight)
  whole_eval <- ELPGV.eval(para_deliver$indepedent_pheno[para_deliver$train_num],weight_predict,type=type)
  return(whole_eval)
}

#' @title ELPGV function
#' @description Prediction of genetic values based on ensemble learning.
#' @param rep_times Number of repetitions.
#' @param interation_times  Number of iterations.
#' @param weight_dimension The number of basic models for ensemble.
#' @param weight_min Minimum value of training weight range.
#' @param weight_max Maximum value of training weight range.
#' @param rate_min The minimum value of the rate range of particle swarm optimization.
#' @param rate_max The maximum value of the rate range of particle swarm optimization.
#' @param paticle_number Initial population number of particle swarm optimization and differential evolution algorithm.
#' @param train_matrix Matrix of training data.
#' @param test_matrix Matrix of testing data.
#' @param CR Crossover probability of differential evolution algorithm.
#' @param R Mutation probability of differential evolution algorithm.
#' @param IW Inertia weight of particle swarm optimization.
#' @param AF1 The first acceleration factor of particle swarm optimization.
#' @param AF2 The second acceleration factor of particle swarm optimization.
#'
#' @return $ELPGV_pred Prediction value of ELPGV model.
#' @export
#' @examples
#' not run
#' rm(list=ls())
#' library("ELPGV")
#' data("data_example")
#' train_matrix <- cbind(data_example$y_real,data_example$BayesA_predict,data_example$BayesB_predict,data_example$BayesCpi_predict,data_example$GBLUP_predict)
#' test_matrix <- cbind(data_example$BayesA_predict,data_example$BayesB_predict,data_example$BayesCpi_predict,data_example$GBLUP_predict)
#'
#' ELPGV_pred <- ELPGV(rep_times = 100,interation_times=20,weight_dimension=ncol(test_matrix),weight_min=0,
#'                   weight_max=1,rate_min=-0.01,rate_max=0.01,paticle_number=20,train_matrix=train_matrix,
#'                   CR = 1.0, test_matrix=test_matrix,R = 0.5, IW = 1, AF1 = 2, AF2 = 2, type ="cor")
#'
#'####
ELPGV <- function(rep_times, interation_times, weight_dimension, weight_min, weight_max, rate_min, rate_max,
                  paticle_number, train_matrix, test_matrix, CR, R, IW, AF1, AF2, type ="cor"){
  options(warn =-1)
  ELPGV.welcome()
  para_deliver <- list()
  para_deliver$predict_models <- train_matrix[,2:ncol(train_matrix)]
  para_deliver$indepedent_pheno <- train_matrix[,1]
  para_deliver$train_num <- c(1:length(train_matrix[,1]))
  best_weight_rep <- matrix(NA,ncol(train_matrix)-1,rep_times)
  CR <- CR
  R <- R
  IW <- IW
  AF1 <- AF1
  AF2 <- AF2
  pb <- txtProgressBar(min = 1,max = rep_times,style = 3)
  for(rep in 1:rep_times){
    Paremeter_matrix<-DEPSO_initialized(weight_dimension,weight_min,weight_max,rate_min,rate_max,
                                        paticle_number,para_deliver,IW,AF1,AF2,CR,R)
    Weight<-matrix(0,nrow=2,ncol=interation_times)
    for(j in 1:interation_times){
      Paremeter_matrix<-DEPSO_optimized(Paremeter_matrix,weight_dimension,weight_min,weight_max,rate_min,rate_max,
                                        paticle_number,para_deliver,IW,AF1,AF2,CR,R)
      Global<-Paremeter_matrix[(paticle_number+1),1:weight_dimension]
      Weight[2,j]<-DEPSO_fitness(Global, para_deliver, type=type)
      if(DEPSO_fitness(Global, para_deliver, type=type)>0.999) break

    }
    best_weight_rep[,rep] <- Global
    setTxtProgressBar(pb, rep)

  }
  close(pb)
  weight<- apply(best_weight_rep,1, mean)
  ELPGV_pred <- test_matrix %*% (weight/sum(weight))
  return(ELPGV_pred)
}

