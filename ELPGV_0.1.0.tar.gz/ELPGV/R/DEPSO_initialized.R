#' @title DEPSO initialization function
#'
#' @param weight_dimension The number of basic models for ensemble.
#' @param weight_min Minimum value of training weight range.
#' @param weight_max Maximum value of training weight range.
#' @param rate_min The minimum value of the rate range of particle swarm optimization.
#' @param rate_max The maximum value of the rate range of particle swarm optimization.
#' @param paticle_number Initial population number of particle swarm optimization and differential evolution algorithm.
#' @param para_deliver A list contains the $predict_models, $indepedent_pheno and $train_num.
#' @param IW Inertia weight of particle swarm optimization.
#' @param AF1 The first acceleration factor of particle swarm optimization.
#' @param AF2 The second acceleration factor of particle swarm optimization.
#' @param CR Crossover probability of differential evolution algorithm.
#' @param R Mutation probability of differential evolution algorithm.
#'
#' @return Initial values of basic variables including particle swarm optimization and differential evolution.
#' @export
#' @examples
DEPSO_initialized<-function(weight_dimension, weight_min, weight_max, rate_min, rate_max,
                            paticle_number, para_deliver, IW, AF1, AF2, CR, R, type ="cor")
{
  PSO_Weight<-matrix(runif(paticle_number*weight_dimension,weight_min,weight_max),nrow=paticle_number,ncol=weight_dimension)
  PSO_Rate<-matrix(runif(paticle_number*weight_dimension,rate_min,rate_max),nrow=paticle_number,ncol=weight_dimension)
  PSO_Fitness<-apply(PSO_Weight,1,
                     function(ccc){
                       return(DEPSO_fitness(ccc, para_deliver, type=type))
                     }
  )
  PSO_max <- which(PSO_Fitness==max(PSO_Fitness))[1]
  PSO_Global<-cbind(PSO_Weight,PSO_Rate,PSO_Fitness)[PSO_max,]
  PSO_Global_new<-cbind(PSO_Weight,PSO_Fitness)[PSO_max,]
  DE_Weight<-matrix(runif(paticle_number*weight_dimension,weight_min,weight_max),nrow=paticle_number,ncol=weight_dimension)
  DE_Fitness<-apply(DE_Weight,1,
                    function(ccc){
                      return(DEPSO_fitness(ccc, para_deliver, type=type))
                    }
  )
  DE_max <- which(DE_Fitness==max(DE_Fitness))[1]
  DE_Global<-cbind(DE_Weight,DE_Fitness)[DE_max,]
  PSO_Rate_new <- matrix(rep(PSO_Rate[PSO_max,1], paticle_number), ncol=1)
  for(i in 2:weight_dimension){
    PSO_Rate_new <- cbind(PSO_Rate_new,matrix(rep(PSO_Rate[PSO_max,i], paticle_number), ncol=1))
  }
  DE_Global_new<-cbind(DE_Weight,PSO_Rate_new,DE_Fitness)[DE_max,]
  if(PSO_Fitness[PSO_max]>DE_Fitness[DE_max]){
    return(cbind(rbind(cbind(PSO_Weight,PSO_Rate,PSO_Fitness),PSO_Global),rbind(cbind(DE_Weight,DE_Fitness),PSO_Global_new)))
  }
  else{
    return(cbind(rbind(cbind(PSO_Weight,PSO_Rate,PSO_Fitness),DE_Global_new),rbind(cbind(DE_Weight,DE_Fitness),DE_Global)))
  }
}
