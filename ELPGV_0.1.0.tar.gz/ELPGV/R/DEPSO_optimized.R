#' @title DEPSO optimized function
#'
#' @param Paremeter_matrix Including the basic variables of particle swarm optimization and differential evolution algorithm.
#' @param weight_dimension The number of basic models for ensemble.
#' @param weight_min Minimum value of training weight range.
#' @param weight_max Maximum value of training weight range.
#' @param rate_min The minimum value of the rate range of particle swarm optimization.
#' @param rate_max The maximum value of the rate range of particle swarm optimization.
#' @param paticle_number Initial population number of particle swarm optimization and differential evolution algorithm.
#' @param para_deliver A list contains the $predict_models, $indepedent_pheno and $train_num.
#' @param IW Inertia weight of particle swarm optimization.
#' @param AF1 The first acceleration factor of particle swarm optimization.
#' @param AF2 The second acceleration factor of particle swarm optimization.
#' @param CR Crossover probability of differential evolution algorithm.
#' @param R Mutation probability of differential evolution algorithm.
#'
#' @return $DEPSO_Global_update The global optimal weights of all populations in DEPSO.
#' @export
#' @examples
DEPSO_optimized<-function(Paremeter_matrix, weight_dimension, weight_min, weight_max, rate_min, rate_max,
                          paticle_number, para_deliver, IW, AF1, AF2, CR, R, type ="cor")
{
  PSO_Weight<-Paremeter_matrix[-(paticle_number+1),1:weight_dimension]
  PSO_Rate<-Paremeter_matrix[-(paticle_number+1),(weight_dimension+1):(2*weight_dimension)]
  PSO_Fitness<-Paremeter_matrix[-(paticle_number+1),2*weight_dimension+1]
  PSO_Paremeter_matrix <- Paremeter_matrix[,1:(2*weight_dimension+1)]
  DE_Weight<-Paremeter_matrix[-(paticle_number+1),(2*weight_dimension+2):(3*weight_dimension+1)]
  DE_Fitness<-Paremeter_matrix[-(paticle_number+1),(3*weight_dimension+2)]
  DE_Weight_next_1<-matrix(NA,nrow=paticle_number,ncol=weight_dimension)
  DE_Weight_next_2<-matrix(NA,nrow=paticle_number,ncol=weight_dimension)
  DE_Weight_next<-matrix(NA,nrow=paticle_number,ncol=weight_dimension)
  DE_son<-matrix(NA,nrow=paticle_number,ncol=weight_dimension)
  for(i in 1:paticle_number)
  {
    New_weight<-PSO_Weight[i,]+PSO_Rate[i,]
    for(j in 1:weight_dimension)
    {
      if(New_weight[j]>weight_max || New_weight[j]<weight_min || is.na(New_weight[j]))
      {
        New_weight[j]<-runif(1,weight_min,weight_max)
      }
    }
    if(DEPSO_fitness(New_weight, para_deliver, type=type)>DEPSO_fitness(PSO_Weight[i,], para_deliver, type=type))
    {
      PSO_Rate[i,]<-IW*PSO_Rate[i,]+AF1*runif(1,0,1)*(New_weight-PSO_Weight[i,])+AF2*runif(1,0,1)*(PSO_Paremeter_matrix[paticle_number+1,1:length(PSO_Weight[i,])]-PSO_Weight[i,])
      PSO_Weight[i,]<-New_weight
      for(k in 1:weight_dimension)
      {
        if(PSO_Rate[i,k]>rate_max || PSO_Rate[i,k]<rate_min || is.na(PSO_Rate[i,k])){
          PSO_Rate[i,k]=runif(1,rate_min,rate_max)     }
      }
      PSO_Fitness[i]<-DEPSO_fitness(New_weight, para_deliver, type=type)
    }
    else{
      PSO_Rate[i,]<-IW*PSO_Rate[i,]+AF2*runif(1,0,1)*(PSO_Paremeter_matrix[paticle_number+1,1:length(PSO_Weight[i,])]-PSO_Weight[i,])
      for(k in 1:weight_dimension)
      {
        if(PSO_Rate[i,k]>rate_max || PSO_Rate[i,k]<rate_min || is.na(PSO_Rate[i,k])){
          PSO_Rate[i,k]=runif(1,rate_min,rate_max)     }
      }
    }
  }
  for(i in 1:paticle_number)
  {
    idx <- sample(1:paticle_number,size=paticle_number,replace=FALSE)
    p<-idx[1]
    k<-idx[2]
    q<-idx[3]
    if(p==i){
      p=idx[4]
    }else if(k==i)
    {
      k=idx[4]
    }else if(q==i)
    {q=idx[4]}
    DE_son[i,]<-DE_Weight[p,]+R*(DE_Weight[k,]-DE_Weight[q,])
    for(j in 1:weight_dimension)
    {
      if(DE_son[i,j]>weight_min && DE_son[i,j]<weight_max)
      {
        DE_Weight_next_1[i,j] = DE_son[i,j]
      }
      else{
        DE_Weight_next_1[i,j] = runif(1,weight_min,weight_max)
      }
    }
  }
  for(i in 1:paticle_number){
    rand<-runif(weight_dimension,0,1)
    for(j in 1:weight_dimension){
      if(rand[j]>CR){
        DE_Weight_next_2[i,j] = DE_Weight[i,j]
      }else{DE_Weight_next_2[i,j] = DE_Weight_next_1[i,j]
      }
    }
  }
  for(i in 1:paticle_number){
    if(DEPSO_fitness(DE_Weight_next_2[i,], para_deliver, type=type)>DEPSO_fitness(DE_Weight[i,], para_deliver,type ="cor"))
    {
      DE_Weight_next[i,]<-DE_Weight_next_2[i,]
    }else{
      DE_Weight_next[i,]<-DE_Weight[i,]
    }
  }
  DE_Fitness<-apply(DE_Weight_next,1,function(ccc){return(DEPSO_fitness(ccc, para_deliver, type=type))})
  DEPSO_Global<- rbind(cbind(PSO_Weight,PSO_Rate,PSO_Fitness,DE_Weight_next,DE_Fitness),Paremeter_matrix[(paticle_number+1),])
  DEPSO_Global_update<-DEPSO_global_update(DEPSO_Global,weight_dimension,paticle_number)
  return(DEPSO_Global_update)
}
