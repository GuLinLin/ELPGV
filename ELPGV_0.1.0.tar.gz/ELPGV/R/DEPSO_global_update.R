#' @title DEPSO global update function
#'
#' @param Paremeter_matrix Including the basic variables of particle swarm optimization and differential evolution algorithm.
#' @param weight_dimension The number of basic models for ensemble.
#' @param paticle_number Initial population number of particle swarm optimization and differential evolution algorithm.
#'
#' @return The global optimal weight of DEPSO.
#' @export
#' @examples
DEPSO_global_update<-function(Paremeter_matrix,weight_dimension,paticle_number)
{
  PSO_Weight <- Paremeter_matrix[,1:weight_dimension]
  DE_Weight <- Paremeter_matrix[,(2*weight_dimension+2):(3*weight_dimension+1)]
  PSO_Fitness <- Paremeter_matrix[,2*weight_dimension+1]
  DE_Fitness <- Paremeter_matrix[,3*weight_dimension+2]
  PSO_Rate <- Paremeter_matrix[,(weight_dimension+1):(2*weight_dimension)]
  PSO_max <- which(PSO_Fitness==max(PSO_Fitness))[1]
  DE_max <- which(DE_Fitness==max(DE_Fitness))[1]
  PSO_Global<-cbind(PSO_Weight,PSO_Rate,PSO_Fitness)[PSO_max,]
  PSO_Global_new<-cbind(PSO_Weight,PSO_Fitness)[PSO_max,]
  DE_Global<-cbind(DE_Weight,DE_Fitness)[DE_max,]
  PSO_Rate_new <- matrix(rep(PSO_Rate[PSO_max,1], paticle_number+1), ncol=1)
  for(i in 2:weight_dimension)
  {
    PSO_Rate_new <- cbind(PSO_Rate_new,matrix(rep(PSO_Rate[PSO_max,i], paticle_number+1), ncol=1))
  }
  DE_Global_new<-cbind(DE_Weight,PSO_Rate_new,DE_Fitness)[DE_max,]
  if(PSO_Fitness[PSO_max]>DE_Fitness[DE_max])
  {
    return(cbind(rbind(cbind(PSO_Weight[-(paticle_number+1),],PSO_Rate[-(paticle_number+1),],PSO_Fitness[-(paticle_number+1)]),PSO_Global),rbind(cbind(DE_Weight[-(paticle_number+1),],DE_Fitness[-(paticle_number+1)]),PSO_Global_new)))
  }else{
    return(cbind(rbind(cbind(PSO_Weight[-(paticle_number+1),],PSO_Rate[-(paticle_number+1),],PSO_Fitness[-(paticle_number+1)]),DE_Global_new),rbind(cbind(DE_Weight[-(paticle_number+1),],DE_Fitness[-(paticle_number+1)]),DE_Global)))
  }
}
