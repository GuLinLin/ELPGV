########################## load example data ###########################
#' @name data_example
#' @title Run a examples for an in-development function.
#' @description
#' A list including:
#' \itemize{
#' \item{y_real:} {A matrix, is the observed phenotype.}
#' \item{BayesA_predict:} {A matrix,is the predicted values based on BayesA.}
#' \item{BayesB_predict:} {A matrix,is the predicted values based on BayesB.}
#' \item{BayesCpi_predict:} {A matrix,is the predicted values based on BayesCpi.}
#' \item{GBLUP_predict:} {A matrix,is the predicted values based on GBLUP.}
#' }
#' @docType data
#' @usage data(data_example)
NULL
